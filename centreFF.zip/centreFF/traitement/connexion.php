<?php
  session_start();
  ?>

<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <link rel="stylesheet" type="text/css" href="../styles/index.css" />
    <title> Centre Frantz Fanon </title>
  </head>

  <body>
<div id="entete">
<img id="logo" src="" alt="logo du site"/>
    <h1> Centre Frantz Fanon </h1>
</div>

<ul id="menu-deroulant">

  <li><a href="../index.php">Accueil</a> </li>
  <li><a href="contact/contact.php">Contact</a> </li>
<?php

if(isset($_SESSION['client']))
{
  echo "Bonjour";
  echo " ";
  echo $_SESSION['client']['Prenom'];
  echo " ";
  echo $_SESSION['client']['Nom'];
  echo '<li>
      <a href="panier.php">
     Panier
     </a>
     </li>';
  echo '<li>
     <a href="historique.php">
     Historique
       </a>
       </li>';
  echo '<li>
  <a href="deconnexion.php"> Déconnexion </a>
  </li>';
}

else
{
    echo '<li>
     <a href="nouveau.php">
       Nouveau patient
       </a>
       </li>';

       echo ' <li>
       <a href="connexion.php">
       Se connecter
       </a></li>';

       echo'<li>
       <a href="inscription.php">
       Inscription
       </a></li>';
}

?>
</ul>

  </body>
  </html>

<form method="post" action="connecter.php" autocomplete="on">
Adresse e-mail : <input type="text" name="mail" value=""/><br/>
Mot de passe : <input type="password" name="mdp1" value=""/><br/>
<input type="submit" name="genre" value="Envoyer"/>
  </form>

</body>
</html>
