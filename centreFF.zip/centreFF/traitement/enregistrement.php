        <?php

        echo '<meta http-equiv="refresh" content="10; URL=fichesuivi.php"/>';

          include('bd.php');
          $bdd= getBD();
          $pat = "insert into patients(numdossier, nompatient,
          nationalité, nompsy, nomtrad, langue,
           téléphonetrad, genre, datenaissance, etudeouprof, situationsoc,
          presenfants, adresse, telephone, situlegadm, lieuresidence, accessoin,
           dureesejour, evntvietrauma, conditionpatient, expresclidiag, dateaccueil, origineref) values(
             '".$_POST['numdoss']."',
             '".$_POST['nompa']."',
             '".$_POST['natio']."',
             '".$_POST['nompsy']."',
             '".$_POST['nomtrad']."',
             '".$_POST['lang']."',
             '".$_POST['teltrad']."',
             '".$_POST['genre']."',
             '".$_POST['datenaiss']."',
             '".$_POST['etudouprof']."',
             '".$_POST['situsoc']."',
             '".$_POST['enfants']."',
             '".$_POST['adr']."',
             '".$_POST['telpat']."',
             '".$_POST['sitlegadm']."',
             '".$_POST['dom']."',
             '".$_POST['soin']."',
             '".$_POST['dureesej']."',
             '".$_POST['eventr']."',
             '".$_POST['condition']."',
             '".$_POST['exprclidiag']."',
             '".$_POST['date1']."',
             '".$_POST['origine']."'
           );";
        echo $pat;
        $bdd -> query($pat);

        $trad = "insert into traducteurs(nomtrad, languetrad, teltrad) values(
          '".$_POST['nomtrad']."',
          '".$_POST['lang']."',
          '".$_POST['teltrad']."'
        );";
        echo $trad;
        $bdd -> query($trad);

        $thrp = "insert into therapie(numdossierpatient, typetherapie)
        values(
          '".$_POST['numdoss']."',
          '".$_POST['thrp']."'
        );";
        echo $thrp;
        $bdd -> query($thrp);

        $souffrances = "insert into souffrances(numdossierpatient,
        souffrancepays, souffranceexil, souffrancefrance) values(
          '".$_POST['numdoss']."',
          '".$_POST['souffrpays']."',
          '".$_POST['souffrexil']."',
          '".$_POST['souffrfr']."'
        );";
        echo $souffrances;
        $bdd -> query($souffrances);

        $projetth = "insert into projetth(numdossierpatient, difficulterencontree, projettherap)
        values(
          '".$_POST['numdoss']."',
          '".$_POST['diffp']."',
          '".$_POST['prjth']."'
        );";
        echo $projetth;
        $bdd -> query($projetth);

        $evalsympt = "insert into evaluationsymptomatique(numdossierpatient, date_der_consult,
        suivireal, arretsuivi, motif_fin_cure, appreciation_accompagnement)
        values(
          '".$_POST['numdoss']."',
          '".$_POST['datederconsultsymp']."',
          '".$_POST['suivireal']."',
          '".$_POST['arretsuivi']."',
          '".$_POST['motif']."',
          '".$_POST['choix1']."'
        );";
        echo $evalsympt;
        $bdd -> query($evalsympt);

        $evolpsy = "insert into evolution_psychosociale(numdossierpatient,
        date_der_consult, statut_admin_sortie, hebergement,
        suivi_mis_en_place, appreciation_accompagnement)
        values(
          '".$_POST['numdoss']."',
          '".$_POST['datederconsultpsy']."',
          '".$_POST['statadmsort']."',
          '".$_POST['heberg']."',
          '".$_POST['smp']."',
          '".$_POST['choix2']."'
        );";
        echo $evolpsy;
        $bdd -> query($evolpsy);

        $evolmed = "insert into evolution_med(numdossierpatient, date_der_consult, ref_psychiatrique,
        suivi_mis_en_place, appreciation_accompagnement) values(
          '".$_POST['numdoss']."',
          '".$_POST['datederconsultmed']."',
          '".$_POST['refpsy']."',
          '".$_POST['smpmed']."',
          '".$_POST['choix3']."'
        );";
        echo $evolmed;
        $bdd -> query($evolmed);
     ?>
