<?php
  session_start();
  ?>

<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <link rel="stylesheet" type="text/css" href="../styles/index.css" />
    <title> Centre Frantz Fanon </title>
    <script type="text/javascript">

      function afficher(etat)
      {
        document.getElementById("champ1").style.visibility=etat;
      }

      function afficher2(etat)
      {
        document.getElementById("champ2").style.visibility=etat;
      }

</script>

  </head>

  <body>
<div id="entete">
<img id="logo" src="" alt="logo du site"/>
    <h1> Centre Frantz Fanon </h1>
</div>

<ul id="menu-deroulant">

  <li><a href="../index.php">Accueil</a> </li>
  <li><a href="../contact/contact.php">Contact</a> </li>
<?php

if(isset($_SESSION['client']))
{
  echo "Bonjour";
  echo " ";
  echo $_SESSION['client']['Prenom'];
  echo " ";
  echo $_SESSION['client']['Nom'];
  echo '<li>
      <a href="panier.php">
     Panier
     </a>
     </li>';
  echo '<li>
     <a href="historique.php">
     Historique
       </a>
       </li>';
  echo '<li>
  <a href="deconnexion.php"> Déconnexion </a>
  </li>';
}

else
{
    echo '<li>
     <a href="nouveau.php">
       Nouveau patient
       </a>
       </li>';

       echo ' <li>
       <a href="connexion.php">
       Se connecter
       </a></li>';

       echo'<li>
       <a href="inscription.php">
       Inscription
       </a></li>';
}

?>

</ul>
<br><br>
<form method="post" action="enregistrement.php" autocomplete="on">

  Vous êtes:<br>
  Un professionnel: <input type="radio" name="choix" value="" onclick='afficher("visible"); afficher2("hidden")'/><br/>
  Un patient: <input type="radio" name="choix" value="" onclick='afficher("hidden"); afficher2("visible")' /><br/>
</form>
<br>
<div id="champ1">
  <form action="enregistrement.php" method="post" autocomplete="on">

    Nom: <input type="text" name="n" value=""><br><br>
    Prénom: <input type="text" name="p" value=""><br><br>
    Profession:
    <select name="type">
      <option value="interprete">Interprète</option>
      <option value="autre">Centre d'hébergement</option>
      <option value="autre">Professionnel de santé</option>
      <option value="autre">Autre</option>
    </select><br><br>
    Adresse mail: <input type="text" name="mail" value=""><br><br>
    Numéro de téléphone: <input type="number" name="num" value=""><br><br>
    Mot de passe: <input type="text" name="mdp1" value=""><br><br>
    Confirmer votre mot de passe: <input type="text" name="mdp2" value="">
  </form>
</div>
<div id="champ2">
  <a href="nouveau.php"> Nouveau patient </a>
</div>
</body>
</html>
