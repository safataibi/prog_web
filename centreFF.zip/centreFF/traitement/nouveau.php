<?php
  session_start();
  ?>

<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <link rel="stylesheet" type="text/css" href="../styles/index.css" />
    <title> Centre Frantz Fanon </title>
  </head>

  <body>
<div id="entete">
<img id="logo" src="" alt="logo du site"/>
    <h1> Centre Frantz Fanon </h1>
</div>

<ul id="menu-deroulant">

  <li><a href="../index.php">Accueil</a> </li>
  <li><a href="../contact/contact.php">Contact</a> </li>
<?php

if(isset($_SESSION['client']))
{
  echo "Bonjour";
  echo " ";
  echo $_SESSION['client']['Prenom'];
  echo " ";
  echo $_SESSION['client']['Nom'];
  echo '<li>
  <a href="deconnexion.php"> Déconnexion </a>
  </li>';
}

else
{
    echo '<li>
     <a href="nouveau.php">
       Nouveau patient
       </a>
       </li>';

       echo ' <li>
       <a href="connexion.php">
       Se connecter
       </a></li>';

       echo'<li>
       <a href="inscription.php">
       Inscription
       </a></li>';
}

?>
</ul>

<h2> Demande de consultation </h2>

<h3> Renseignements adminstratifs </h3>
  <form method="post" action="demande.php" autocomplete="on">
Nom: <input type="text" name="n" value=""/><br/>
<br>
Prénom: <input type="text" name="p" value=""/><br/>
<br>
Adresse actuelle: <input type="text" name="adr" value=""/><br/>
<br>
Numéro de téléphone: <input type="text" name="num" value=""/><br/>
<br>
Pays d'origine : <input type="text" name="pays_org" value=""/><br/>
<br>
Date d'arrivée en France : <input type="text" name="date_arr" value=""/><br/>
<br>
Langue parlée: <input type="text" name="langue" value=""/>
<br>
<br>
Présence d'un interprète nécessaire?:
Oui : <input type="radio" name="interprete" value="oui" /><br/>
Non : <input type="radio" name="interprete" value="non" /><br/>
<br>

<h3> Situation Sociale </h3>

  Situation sociale et juridique: <input type="text" name="ssj" value="">
  <br> <br>
  Mode d'hébergement : <input type="text" name="heberg" value="">
  <br><br>
  Nom du référent social : <input type="text" name="refsoc" value="">
  <br><br>
  Droits ouverts: <input type="text" name="droitsouv" value="">
  <br><br>

<h3>Histoire et motif de la demande:</h3>
<textarea name="histoire" rows="20" cols="80"></textarea>
<br><br>
<h3>Plaintes psychologiques et somatiques:</h3>
<textarea name="plaintesps" rows="20" cols="80"></textarea>

<h3> Suivi médical </h3>
  Nom du médecin traitant: <input type="text" name="medt" value="">
  <br><br>
  Traitement éventuel: <input type="text" name="traitemt" value="">
  <br><br>
  Antécédents notables: <input type="text" name="anten" value="">
  <br><br>
  Autre référent médical: <input type="text" name="autreref" value="">
  <br><br>
  <input type="submit" name="sub" value="Envoyer">
</form>
</body>
</html>
