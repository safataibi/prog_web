<?php
  session_start();

  include('bd.php');
  $bdd= getBD();
  $q="select * from clients
    where
    mail='".$_POST['mail']."'
    and mdp='".$_POST['mdp1']."'
    ";
  echo $q;
  $req= $bdd->query($q);
  $c = $req->fetch();

if($c['mail']=="" || $c['mdp']=="")
{
  echo '<meta http-equiv="refresh" content="10; URL=connexion.php"/>';
}

else
{
  $_SESSION['client']=array(
    'ID' => $c['id_client'],
    'Nom' => $c['nom'],
    'Prenom' => $c['prenom'],
    'Mail' => $c['mail'],
    'Mot de passe' => $c['mdp']
  );

  echo '<meta http-equiv="refresh" content="10; URL=../index.php"/>';
}

?>
